/* KaziRemote — shared UI: header, footer, theme, sign-in, toasts, job cards. */
(function () {
  const S = window.KaziStore;
  const $ = (sel, root = document) => root.querySelector(sel);

  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const initials = (name) => String(name).split(/\s+/).map((w) => w[0]).join("").slice(0, 2).toUpperCase();
  const ago = (d) => (d === 0 ? "Today" : d === 1 ? "1 day ago" : d > 30 ? "30+ days ago" : d + " days ago");
  const fmtKES = (n) => S.config.CURRENCY + " " + Number(n).toLocaleString();

  const ICONS = {
    sun: '<svg class="sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>',
    moon: '<svg class="moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>',
    menu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 6h16M4 12h16M4 18h16"/></svg>',
    google: '<svg viewBox="0 0 48 48"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="m6.3 14.7 6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z"/></svg>',
    pin: "📍", clock: "🕒", briefcase: "💼",
  };

  // ---------- Theme ----------
  function toggleTheme() {
    const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    localStorage.setItem("kazi:theme", next);
  }

  // ---------- Toast ----------
  function toast(msg) {
    let wrap = $(".toast-wrap");
    if (!wrap) { wrap = document.createElement("div"); wrap.className = "toast-wrap"; wrap.setAttribute("role", "status"); document.body.appendChild(wrap); }
    const t = document.createElement("div");
    t.className = "toast"; t.textContent = msg;
    wrap.appendChild(t);
    setTimeout(() => t.remove(), 3200);
  }

  // ---------- Header / footer ----------
  const NAV = [
    { href: "/jobs.html", label: "Find jobs", key: "jobs" },
    { href: "/post-job.html", label: "Post a job", key: "post" },
    { href: "/enroll.html", label: "Enroll", key: "enroll" },
  ];

  function renderAuth() {
    const slot = $("#auth-slot");
    if (!slot) return;
    const user = S.currentUser();
    if (user) {
      const status = S.enrollment();
      const badge = status === "active" ? '<span class="badge badge-brand">Enrolled</span>' : status === "pending" ? '<span class="badge badge-warn">Pending</span>' : "";
      slot.innerHTML = `<button class="user-chip" id="user-chip" title="Sign out"><span class="avatar">${esc(user.initials)}</span><span class="hide-sm">${esc(user.name.split(" ")[0])}</span>${badge}</button>`;
      $("#user-chip").onclick = () => { S.signOut(); toast("Signed out"); renderAuth(); document.dispatchEvent(new CustomEvent("kazi:auth")); };
    } else {
      slot.innerHTML = `<button class="btn google-btn btn-sm" id="google-signin">${ICONS.google}<span>Sign in<span class="hide-sm"> with Google</span></span></button>`;
      $("#google-signin").onclick = signIn;
    }
  }

  function signIn() {
    // Stub: real Google OAuth arrives with Netlify Identity (PLAN.md, milestone 3).
    const u = S.signInDemo();
    toast(`Signed in as ${u.name} (demo Google account)`);
    renderAuth();
    document.dispatchEvent(new CustomEvent("kazi:auth"));
  }

  // Hidden admin entry: 5 taps on the logo within 3 seconds opens /admin.html.
  // A single tap still goes home, after a short pause to tell it apart from a sequence.
  function bindSecretLogo(logo) {
    const TAPS = 5, WINDOW_MS = 3000, HOME_DELAY_MS = 800;
    let taps = [], homeTimer;
    logo.addEventListener("click", (e) => {
      e.preventDefault();
      clearTimeout(homeTimer);
      const now = Date.now();
      taps = [...taps.filter((t) => now - t < WINDOW_MS), now];
      if (taps.length >= TAPS) { taps = []; location.href = "/admin.html"; return; }
      if (location.pathname !== "/" && location.pathname !== "/index.html") {
        homeTimer = setTimeout(() => { location.href = "/"; }, HOME_DELAY_MS);
      }
    });
  }

  function renderChrome() {
    const page = document.body.dataset.page;
    const header = $("#site-header");
    if (header) {
      header.className = "site-header";
      header.innerHTML = `
        <div class="container nav">
          <a class="logo" href="/"><span class="logo-mark">K</span><span>Kazi<em>Remote</em></span></a>
          <nav class="nav-links" id="nav-links" aria-label="Main">
            ${NAV.map((n) => `<a href="${n.href}" ${n.key === page ? 'aria-current="page"' : ""}>${n.label}</a>`).join("")}
          </nav>
          <div class="nav-actions">
            <button class="icon-btn theme-toggle" id="theme-toggle" aria-label="Toggle dark mode">${ICONS.sun}${ICONS.moon}</button>
            <span id="auth-slot"></span>
            <button class="icon-btn menu-btn" id="menu-btn" aria-label="Open menu">${ICONS.menu}</button>
          </div>
        </div>`;
      bindSecretLogo($(".logo", header));
      $("#theme-toggle").onclick = toggleTheme;
      $("#menu-btn").onclick = () => $("#nav-links").classList.toggle("open");
      renderAuth();
    }
    const footer = $("#site-footer");
    if (footer) {
      footer.className = "site-footer";
      footer.innerHTML = `
        <div class="container footer-row">
          <div><strong style="color:var(--ink)">KaziRemote</strong> — remote work for African talent. © 2026</div>
          <nav><a href="/jobs.html">Jobs</a><a href="/post-job.html">Employers</a><a href="/enroll.html">Enroll</a></nav>
          <span class="demo-note">Preview build · sample data <a href="#" id="reset-demo">reset</a></span>
        </div>`;
      $("#reset-demo").onclick = (e) => { e.preventDefault(); S.resetDemo(); location.reload(); };
    }
  }

  // ---------- Job card + detail ----------
  function catLabel(id) { return (S.categories.find((c) => c.id === id) || {}).label || id; }

  function jobCard(job) {
    return `
      <button class="job-card ${job.featured ? "featured" : ""}" data-job="${esc(job.id)}">
        <span class="company-logo" style="background:${esc(job.color || "#555")}">${esc(initials(job.company))}</span>
        <span>
          <h3>${esc(job.title)}</h3>
          <span class="job-meta"><span>${esc(job.company)}</span><span>${ICONS.pin} ${esc(job.location)}</span><span>${ICONS.briefcase} ${esc(job.type)}</span></span>
          <span class="tags">${(job.tags || []).map((t) => `<span class="tag">${esc(t)}</span>`).join("")}</span>
        </span>
        <span class="job-side">
          ${job.featured ? '<span class="badge badge-accent">Featured</span>' : ""}
          <span class="salary">${esc(job.salary)}</span>
          <span class="muted" style="font-size:.82rem">${ago(job.posted)}</span>
        </span>
      </button>`;
  }

  function ensureDialog() {
    let d = $("#job-dialog");
    if (d) return d;
    d = document.createElement("dialog");
    d.id = "job-dialog";
    document.body.appendChild(d);
    return d;
  }

  function openJob(id) {
    const job = S.getJob(id);
    if (!job) return;
    const d = ensureDialog();
    const user = S.currentUser();
    const status = S.enrollment();
    const applied = S.applied().includes(job.id);
    let cta;
    if (applied) cta = '<button class="btn btn-ghost" disabled>✓ Application sent</button>';
    else if (!user) cta = `<button class="btn google-btn" data-act="signin">${ICONS.google} Sign in to apply</button>`;
    else if (status === "active") cta = '<button class="btn btn-primary" data-act="apply">Apply now</button>';
    else if (status === "pending") cta = '<button class="btn btn-ghost" disabled>Payment under review</button>';
    else cta = `<a class="btn btn-primary" href="/enroll.html?job=${esc(job.id)}">Enroll to apply · ${fmtKES(S.config.ENROLL_FEE_KES)}</a>`;

    d.innerHTML = `
      <div class="dialog-head">
        <span class="company-logo" style="background:${esc(job.color)}">${esc(initials(job.company))}</span>
        <div><h2 style="font-size:1.45rem;margin:0">${esc(job.title)}</h2><div class="muted">${esc(job.company)} · ${esc(job.location)}</div></div>
        <button class="icon-btn dialog-close" aria-label="Close" data-act="close">✕</button>
      </div>
      <div class="dialog-body job-desc">
        <div class="tags" style="margin:0 0 14px">
          <span class="badge badge-brand">${esc(job.type)}</span>
          <span class="badge badge-muted">${esc(catLabel(job.category))}</span>
          <span class="badge badge-muted">${esc(job.salary)}</span>
          <span class="badge badge-muted">${job.applicants} applicants</span>
        </div>
        <p>${esc(job.summary)}</p>
        <h4>What you'll do</h4><ul>${(job.responsibilities || []).map((r) => `<li>${esc(r)}</li>`).join("")}</ul>
        <h4>What we're looking for</h4><ul>${(job.requirements || []).map((r) => `<li>${esc(r)}</li>`).join("")}</ul>
      </div>
      <div class="dialog-foot"><span class="muted" style="margin-right:auto;font-size:.88rem;align-self:center">Posted ${ago(job.posted).toLowerCase()}</span>${cta}</div>`;
    d.onclick = (e) => {
      const act = e.target.closest("[data-act]")?.dataset.act;
      if (act === "close") d.close();
      if (act === "signin") { signIn(); openJob(id); }
      if (act === "apply") { S.apply(job.id); toast(`Application sent to ${job.company}`); openJob(id); }
      if (e.target === d) d.close();
    };
    if (!d.open) d.showModal();
  }

  // Delegate clicks on any job card on any page
  document.addEventListener("click", (e) => {
    const card = e.target.closest("[data-job]");
    if (card) openJob(card.dataset.job);
  });

  document.addEventListener("DOMContentLoaded", renderChrome);

  window.Kazi = { $, esc, initials, ago, fmtKES, toast, jobCard, openJob, catLabel, signIn, renderAuth };
})();
